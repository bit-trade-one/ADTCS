namespace HID_PnP_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.KeyboardValue_txtbx = new System.Windows.Forms.TextBox();
            this.ToggleLEDToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.PushbuttonStateTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.MouseMove_UD = new System.Windows.Forms.NumericUpDown();
            this.Win_cbox = new System.Windows.Forms.CheckBox();
            this.Shift_cbox = new System.Windows.Forms.CheckBox();
            this.Alt_cbox = new System.Windows.Forms.CheckBox();
            this.Ctrl_cbox = new System.Windows.Forms.CheckBox();
            this.mousevalue_combx = new System.Windows.Forms.ComboBox();
            this.devicetype_combox = new System.Windows.Forms.ComboBox();
            this.devicetype_lbl1 = new System.Windows.Forms.Label();
            this.DeviceAssign_lbl1 = new System.Windows.Forms.Label();
            this.StatusBox_lbl = new System.Windows.Forms.Label();
            this.StatusBox_lbl2 = new System.Windows.Forms.Label();
            this.Hold_CB = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.num_touch_sense = new System.Windows.Forms.NumericUpDown();
            this.joyvalue_combox = new System.Windows.Forms.ComboBox();
            this.lbl_FW_Version = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Speed_Mouse4_lbl = new System.Windows.Forms.Label();
            this.Speed_Mouse6_lbl = new System.Windows.Forms.Label();
            this.Speed_Mouse5_lbl = new System.Windows.Forms.Label();
            this.Key_assign_lbl = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Changevalue_btn = new System.Windows.Forms.Button();
            this.Arrow_Keyboard_pb = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Reset_btn = new System.Windows.Forms.Button();
            this.DevicePb1 = new System.Windows.Forms.PictureBox();
            this.Status_NC_pb = new System.Windows.Forms.PictureBox();
            this.Status_C_pb = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon1 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.MouseMove_UD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_touch_sense)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Keyboard_pb)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DevicePb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon1)).BeginInit();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 6;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // KeyboardValue_txtbx
            // 
            this.KeyboardValue_txtbx.AcceptsTab = true;
            this.KeyboardValue_txtbx.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(85)))), ((int)(((byte)(83)))));
            this.KeyboardValue_txtbx.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.KeyboardValue_txtbx.Location = new System.Drawing.Point(309, 71);
            this.KeyboardValue_txtbx.Name = "KeyboardValue_txtbx";
            this.KeyboardValue_txtbx.Size = new System.Drawing.Size(100, 19);
            this.KeyboardValue_txtbx.TabIndex = 127;
            this.KeyboardValue_txtbx.TabStop = false;
            this.KeyboardValue_txtbx.Text = "�����ɓ���";
            this.KeyboardValue_txtbx.Visible = false;
            this.KeyboardValue_txtbx.TextChanged += new System.EventHandler(this.KeyboardValue_txtbx_TextChanged);
            this.KeyboardValue_txtbx.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.KeyboardValue_txtbx_PreviewKeyDown);
            this.KeyboardValue_txtbx.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyboardValue_txtbx_KeyDown);
            this.KeyboardValue_txtbx.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyboardValue_txtbx_KeyUp);
            // 
            // ToggleLEDToolTip
            // 
            this.ToggleLEDToolTip.AutomaticDelay = 2000;
            this.ToggleLEDToolTip.AutoPopDelay = 20000;
            this.ToggleLEDToolTip.InitialDelay = 15;
            this.ToggleLEDToolTip.ReshowDelay = 15;
            // 
            // PushbuttonStateTooltip
            // 
            this.PushbuttonStateTooltip.AutomaticDelay = 20;
            this.PushbuttonStateTooltip.AutoPopDelay = 20000;
            this.PushbuttonStateTooltip.InitialDelay = 15;
            this.PushbuttonStateTooltip.ReshowDelay = 15;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 2000;
            this.toolTip1.AutoPopDelay = 20000;
            this.toolTip1.InitialDelay = 15;
            this.toolTip1.ReshowDelay = 15;
            // 
            // toolTip2
            // 
            this.toolTip2.AutomaticDelay = 20;
            this.toolTip2.AutoPopDelay = 20000;
            this.toolTip2.InitialDelay = 15;
            this.toolTip2.ReshowDelay = 15;
            // 
            // MouseMove_UD
            // 
            this.MouseMove_UD.BackColor = System.Drawing.SystemColors.Window;
            this.MouseMove_UD.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.MouseMove_UD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(85)))), ((int)(((byte)(83)))));
            this.MouseMove_UD.Location = new System.Drawing.Point(335, 70);
            this.MouseMove_UD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.MouseMove_UD.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.MouseMove_UD.Name = "MouseMove_UD";
            this.MouseMove_UD.Size = new System.Drawing.Size(108, 20);
            this.MouseMove_UD.TabIndex = 128;
            this.MouseMove_UD.TabStop = false;
            this.MouseMove_UD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.MouseMove_UD.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.MouseMove_UD.Visible = false;
            this.MouseMove_UD.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // Win_cbox
            // 
            this.Win_cbox.AutoSize = true;
            this.Win_cbox.BackColor = System.Drawing.SystemColors.Control;
            this.Win_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Win_cbox.Location = new System.Drawing.Point(205, 82);
            this.Win_cbox.Name = "Win_cbox";
            this.Win_cbox.Size = new System.Drawing.Size(42, 16);
            this.Win_cbox.TabIndex = 125;
            this.Win_cbox.Text = "Win";
            this.Win_cbox.UseVisualStyleBackColor = false;
            this.Win_cbox.Visible = false;
            this.Win_cbox.CheckedChanged += new System.EventHandler(this.Win_cbox_CheckedChanged);
            // 
            // Shift_cbox
            // 
            this.Shift_cbox.AutoSize = true;
            this.Shift_cbox.BackColor = System.Drawing.SystemColors.Control;
            this.Shift_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Shift_cbox.Location = new System.Drawing.Point(144, 82);
            this.Shift_cbox.Name = "Shift_cbox";
            this.Shift_cbox.Size = new System.Drawing.Size(48, 16);
            this.Shift_cbox.TabIndex = 124;
            this.Shift_cbox.Text = "Shift";
            this.Shift_cbox.UseVisualStyleBackColor = false;
            this.Shift_cbox.Visible = false;
            this.Shift_cbox.CheckedChanged += new System.EventHandler(this.Shift_cbox_CheckedChanged);
            // 
            // Alt_cbox
            // 
            this.Alt_cbox.AutoSize = true;
            this.Alt_cbox.BackColor = System.Drawing.SystemColors.Control;
            this.Alt_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Alt_cbox.Location = new System.Drawing.Point(205, 65);
            this.Alt_cbox.Name = "Alt_cbox";
            this.Alt_cbox.Size = new System.Drawing.Size(39, 16);
            this.Alt_cbox.TabIndex = 123;
            this.Alt_cbox.Text = "Alt";
            this.Alt_cbox.UseVisualStyleBackColor = false;
            this.Alt_cbox.Visible = false;
            this.Alt_cbox.CheckedChanged += new System.EventHandler(this.Alt_cbox_CheckedChanged);
            // 
            // Ctrl_cbox
            // 
            this.Ctrl_cbox.AutoSize = true;
            this.Ctrl_cbox.BackColor = System.Drawing.SystemColors.Control;
            this.Ctrl_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Ctrl_cbox.Location = new System.Drawing.Point(144, 65);
            this.Ctrl_cbox.Name = "Ctrl_cbox";
            this.Ctrl_cbox.Size = new System.Drawing.Size(43, 16);
            this.Ctrl_cbox.TabIndex = 122;
            this.Ctrl_cbox.Text = "Ctrl";
            this.Ctrl_cbox.UseVisualStyleBackColor = false;
            this.Ctrl_cbox.Visible = false;
            this.Ctrl_cbox.CheckedChanged += new System.EventHandler(this.Ctrl_cbox_CheckedChanged);
            // 
            // mousevalue_combx
            // 
            this.mousevalue_combx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mousevalue_combx.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(85)))), ((int)(((byte)(83)))));
            this.mousevalue_combx.FormattingEnabled = true;
            this.mousevalue_combx.Items.AddRange(new object[] {
            "���N���b�N",
            "�E�N���b�N",
            "�z�C�[���N���b�N",
            "��ړ�",
            "���ړ�",
            "���ړ�",
            "�E�ړ�",
            "�z�C�[����",
            "�z�C�[����"});
            this.mousevalue_combx.Location = new System.Drawing.Point(142, 70);
            this.mousevalue_combx.Name = "mousevalue_combx";
            this.mousevalue_combx.Size = new System.Drawing.Size(121, 20);
            this.mousevalue_combx.TabIndex = 26;
            this.mousevalue_combx.Visible = false;
            this.mousevalue_combx.SelectedIndexChanged += new System.EventHandler(this.mousevalue_combx_SelectedIndexChanged);
            // 
            // devicetype_combox
            // 
            this.devicetype_combox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.devicetype_combox.Enabled = false;
            this.devicetype_combox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(85)))), ((int)(((byte)(83)))));
            this.devicetype_combox.FormattingEnabled = true;
            this.devicetype_combox.Items.AddRange(new object[] {
            "�}�E�X",
            "�L�[�{�[�h",
            "�W���C�p�b�h"});
            this.devicetype_combox.Location = new System.Drawing.Point(141, 24);
            this.devicetype_combox.Name = "devicetype_combox";
            this.devicetype_combox.Size = new System.Drawing.Size(121, 20);
            this.devicetype_combox.TabIndex = 111;
            this.devicetype_combox.SelectedIndexChanged += new System.EventHandler(this.devicetype_combox_SelectedIndexChanged);
            // 
            // devicetype_lbl1
            // 
            this.devicetype_lbl1.AutoSize = true;
            this.devicetype_lbl1.BackColor = System.Drawing.SystemColors.Control;
            this.devicetype_lbl1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(137)))), ((int)(((byte)(140)))));
            this.devicetype_lbl1.Location = new System.Drawing.Point(721, 106);
            this.devicetype_lbl1.Name = "devicetype_lbl1";
            this.devicetype_lbl1.Size = new System.Drawing.Size(33, 12);
            this.devicetype_lbl1.TabIndex = 202;
            this.devicetype_lbl1.Text = "01Pin";
            // 
            // DeviceAssign_lbl1
            // 
            this.DeviceAssign_lbl1.AutoSize = true;
            this.DeviceAssign_lbl1.BackColor = System.Drawing.SystemColors.Control;
            this.DeviceAssign_lbl1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(137)))), ((int)(((byte)(140)))));
            this.DeviceAssign_lbl1.Location = new System.Drawing.Point(721, 122);
            this.DeviceAssign_lbl1.Name = "DeviceAssign_lbl1";
            this.DeviceAssign_lbl1.Size = new System.Drawing.Size(40, 12);
            this.DeviceAssign_lbl1.TabIndex = 204;
            this.DeviceAssign_lbl1.Text = "Assign";
            // 
            // StatusBox_lbl
            // 
            this.StatusBox_lbl.AutoSize = true;
            this.StatusBox_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.StatusBox_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(85)))), ((int)(((byte)(83)))));
            this.StatusBox_lbl.Location = new System.Drawing.Point(756, 206);
            this.StatusBox_lbl.Name = "StatusBox_lbl";
            this.StatusBox_lbl.Size = new System.Drawing.Size(79, 12);
            this.StatusBox_lbl.TabIndex = 303;
            this.StatusBox_lbl.Text = "�f�o�C�X���ڑ�";
            // 
            // StatusBox_lbl2
            // 
            this.StatusBox_lbl2.AutoSize = true;
            this.StatusBox_lbl2.BackColor = System.Drawing.SystemColors.Control;
            this.StatusBox_lbl2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(85)))), ((int)(((byte)(83)))));
            this.StatusBox_lbl2.Location = new System.Drawing.Point(18, 206);
            this.StatusBox_lbl2.Name = "StatusBox_lbl2";
            this.StatusBox_lbl2.Size = new System.Drawing.Size(282, 12);
            this.StatusBox_lbl2.TabIndex = 301;
            this.StatusBox_lbl2.Text = "�����^USB�^�b�`�X�C�b�`, Configuration Tool�N�����܂���";
            // 
            // Hold_CB
            // 
            this.Hold_CB.AutoSize = true;
            this.Hold_CB.Location = new System.Drawing.Point(306, 27);
            this.Hold_CB.Name = "Hold_CB";
            this.Hold_CB.Size = new System.Drawing.Size(15, 14);
            this.Hold_CB.TabIndex = 112;
            this.Hold_CB.UseVisualStyleBackColor = true;
            this.Hold_CB.CheckedChanged += new System.EventHandler(this.Hold_CB_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(137)))), ((int)(((byte)(140)))));
            this.label1.Location = new System.Drawing.Point(327, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 12);
            this.label1.TabIndex = 113;
            this.label1.Text = "�������u�Ԃ̂ݔ�������";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // num_touch_sense
            // 
            this.num_touch_sense.BackColor = System.Drawing.SystemColors.Window;
            this.num_touch_sense.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.num_touch_sense.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(85)))), ((int)(((byte)(83)))));
            this.num_touch_sense.Location = new System.Drawing.Point(146, 145);
            this.num_touch_sense.Maximum = new decimal(new int[] {
            254,
            0,
            0,
            0});
            this.num_touch_sense.Minimum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.num_touch_sense.Name = "num_touch_sense";
            this.num_touch_sense.Size = new System.Drawing.Size(63, 20);
            this.num_touch_sense.TabIndex = 141;
            this.num_touch_sense.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.num_touch_sense.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            // 
            // joyvalue_combox
            // 
            this.joyvalue_combox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.joyvalue_combox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(85)))), ((int)(((byte)(83)))));
            this.joyvalue_combox.FormattingEnabled = true;
            this.joyvalue_combox.Items.AddRange(new object[] {
            "��",
            "��",
            "��",
            "�E",
            "�{�^���P",
            "�{�^���Q",
            "�{�^���R",
            "�{�^���S",
            "�{�^���T",
            "�{�^���U",
            "�{�^���V",
            "�{�^���W",
            "�{�^���X",
            "�{�^���P�O",
            "�{�^���P�P",
            "�{�^���P�Q"});
            this.joyvalue_combox.Location = new System.Drawing.Point(141, 70);
            this.joyvalue_combox.Name = "joyvalue_combox";
            this.joyvalue_combox.Size = new System.Drawing.Size(121, 20);
            this.joyvalue_combox.TabIndex = 121;
            this.joyvalue_combox.Visible = false;
            this.joyvalue_combox.SelectedIndexChanged += new System.EventHandler(this.joyvalue_combox_SelectedIndexChanged);
            // 
            // lbl_FW_Version
            // 
            this.lbl_FW_Version.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_FW_Version.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(85)))), ((int)(((byte)(83)))));
            this.lbl_FW_Version.Location = new System.Drawing.Point(591, 206);
            this.lbl_FW_Version.Name = "lbl_FW_Version";
            this.lbl_FW_Version.Size = new System.Drawing.Size(150, 12);
            this.lbl_FW_Version.TabIndex = 302;
            this.lbl_FW_Version.Text = "FW Version";
            this.lbl_FW_Version.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Speed_Mouse4_lbl);
            this.groupBox1.Controls.Add(this.num_touch_sense);
            this.groupBox1.Controls.Add(this.Speed_Mouse6_lbl);
            this.groupBox1.Controls.Add(this.Speed_Mouse5_lbl);
            this.groupBox1.Controls.Add(this.Key_assign_lbl);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.joyvalue_combox);
            this.groupBox1.Controls.Add(this.devicetype_combox);
            this.groupBox1.Controls.Add(this.Hold_CB);
            this.groupBox1.Controls.Add(this.MouseMove_UD);
            this.groupBox1.Controls.Add(this.Changevalue_btn);
            this.groupBox1.Controls.Add(this.mousevalue_combx);
            this.groupBox1.Controls.Add(this.KeyboardValue_txtbx);
            this.groupBox1.Controls.Add(this.Ctrl_cbox);
            this.groupBox1.Controls.Add(this.Arrow_Keyboard_pb);
            this.groupBox1.Controls.Add(this.Alt_cbox);
            this.groupBox1.Controls.Add(this.Shift_cbox);
            this.groupBox1.Controls.Add(this.Win_cbox);
            this.groupBox1.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(615, 180);
            this.groupBox1.TabIndex = 100;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "���t�ݒ�";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label7.Location = new System.Drawing.Point(214, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(197, 22);
            this.label7.TabIndex = 142;
            this.label7.Text = "[�� 16�`254 �� (Default=64)]";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Silver;
            this.label12.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label12.Location = new System.Drawing.Point(10, 131);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(450, 1);
            this.label12.TabIndex = 102;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label6.Location = new System.Drawing.Point(15, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 16);
            this.label6.TabIndex = 140;
            this.label6.Text = "�Z���T���x�̒���";
            // 
            // Speed_Mouse4_lbl
            // 
            this.Speed_Mouse4_lbl.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Speed_Mouse4_lbl.Location = new System.Drawing.Point(271, 72);
            this.Speed_Mouse4_lbl.Name = "Speed_Mouse4_lbl";
            this.Speed_Mouse4_lbl.Size = new System.Drawing.Size(60, 16);
            this.Speed_Mouse4_lbl.TabIndex = 126;
            this.Speed_Mouse4_lbl.Text = "�ړ����x";
            this.Speed_Mouse4_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Speed_Mouse4_lbl.Visible = false;
            // 
            // Speed_Mouse6_lbl
            // 
            this.Speed_Mouse6_lbl.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Speed_Mouse6_lbl.Location = new System.Drawing.Point(329, 110);
            this.Speed_Mouse6_lbl.Name = "Speed_Mouse6_lbl";
            this.Speed_Mouse6_lbl.Size = new System.Drawing.Size(124, 16);
            this.Speed_Mouse6_lbl.TabIndex = 131;
            this.Speed_Mouse6_lbl.Text = "�iDefault = 50�j";
            this.Speed_Mouse6_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Speed_Mouse6_lbl.Visible = false;
            // 
            // Speed_Mouse5_lbl
            // 
            this.Speed_Mouse5_lbl.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Speed_Mouse5_lbl.Location = new System.Drawing.Point(329, 94);
            this.Speed_Mouse5_lbl.Name = "Speed_Mouse5_lbl";
            this.Speed_Mouse5_lbl.Size = new System.Drawing.Size(124, 16);
            this.Speed_Mouse5_lbl.TabIndex = 130;
            this.Speed_Mouse5_lbl.Text = "�x 001 <---> 255 ��";
            this.Speed_Mouse5_lbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Speed_Mouse5_lbl.Visible = false;
            // 
            // Key_assign_lbl
            // 
            this.Key_assign_lbl.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Key_assign_lbl.Location = new System.Drawing.Point(323, 95);
            this.Key_assign_lbl.Name = "Key_assign_lbl";
            this.Key_assign_lbl.Size = new System.Drawing.Size(100, 16);
            this.Key_assign_lbl.TabIndex = 129;
            this.Key_assign_lbl.Text = "�L�[�̊��蓖��";
            this.Key_assign_lbl.Visible = false;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Silver;
            this.label5.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label5.Location = new System.Drawing.Point(10, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(450, 1);
            this.label5.TabIndex = 101;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.Location = new System.Drawing.Point(483, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 23);
            this.label4.TabIndex = 190;
            this.label4.Text = "�ݒ�𔽉f";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(15, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 23);
            this.label3.TabIndex = 120;
            this.label3.Text = "���蓖��";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(15, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 23);
            this.label2.TabIndex = 110;
            this.label2.Text = "�f�o�C�X�^�C�v";
            // 
            // Changevalue_btn
            // 
            this.Changevalue_btn.Enabled = false;
            this.Changevalue_btn.Location = new System.Drawing.Point(482, 89);
            this.Changevalue_btn.Name = "Changevalue_btn";
            this.Changevalue_btn.Size = new System.Drawing.Size(121, 29);
            this.Changevalue_btn.TabIndex = 191;
            this.Changevalue_btn.Text = "�ݒ�";
            this.Changevalue_btn.UseVisualStyleBackColor = true;
            this.Changevalue_btn.Click += new System.EventHandler(this.Changevalue_btn_Click);
            // 
            // Arrow_Keyboard_pb
            // 
            this.Arrow_Keyboard_pb.BackColor = System.Drawing.Color.Transparent;
            this.Arrow_Keyboard_pb.Image = global::Ultra_Small_Touch_SW_CT.Properties.Resources.KEY_ARROW;
            this.Arrow_Keyboard_pb.Location = new System.Drawing.Point(268, 75);
            this.Arrow_Keyboard_pb.Name = "Arrow_Keyboard_pb";
            this.Arrow_Keyboard_pb.Size = new System.Drawing.Size(12, 11);
            this.Arrow_Keyboard_pb.TabIndex = 114;
            this.Arrow_Keyboard_pb.TabStop = false;
            this.Arrow_Keyboard_pb.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Reset_btn);
            this.groupBox3.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox3.Location = new System.Drawing.Point(636, 147);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(230, 45);
            this.groupBox3.TabIndex = 200;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Firmware Update";
            // 
            // Reset_btn
            // 
            this.Reset_btn.Location = new System.Drawing.Point(35, 18);
            this.Reset_btn.Name = "Reset_btn";
            this.Reset_btn.Size = new System.Drawing.Size(160, 20);
            this.Reset_btn.TabIndex = 201;
            this.Reset_btn.Text = "�A�b�v�f�[�g";
            this.Reset_btn.UseVisualStyleBackColor = true;
            this.Reset_btn.Click += new System.EventHandler(this.Reset_btn_Click);
            // 
            // DevicePb1
            // 
            this.DevicePb1.BackColor = System.Drawing.Color.Transparent;
            this.DevicePb1.Image = global::Ultra_Small_Touch_SW_CT.Properties.Resources.P1470355;
            this.DevicePb1.Location = new System.Drawing.Point(729, 35);
            this.DevicePb1.Name = "DevicePb1";
            this.DevicePb1.Size = new System.Drawing.Size(54, 43);
            this.DevicePb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DevicePb1.TabIndex = 152;
            this.DevicePb1.TabStop = false;
            // 
            // Status_NC_pb
            // 
            this.Status_NC_pb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.Status_NC_pb.Image = global::Ultra_Small_Touch_SW_CT.Properties.Resources.X_NotConnect;
            this.Status_NC_pb.Location = new System.Drawing.Point(843, 208);
            this.Status_NC_pb.Name = "Status_NC_pb";
            this.Status_NC_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_NC_pb.TabIndex = 95;
            this.Status_NC_pb.TabStop = false;
            this.Status_NC_pb.Visible = false;
            // 
            // Status_C_pb
            // 
            this.Status_C_pb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.Status_C_pb.Image = global::Ultra_Small_Touch_SW_CT.Properties.Resources.X_connect;
            this.Status_C_pb.Location = new System.Drawing.Point(843, 208);
            this.Status_C_pb.Name = "Status_C_pb";
            this.Status_C_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_C_pb.TabIndex = 94;
            this.Status_C_pb.TabStop = false;
            this.Status_C_pb.Visible = false;
            // 
            // ButtonPressIcon1
            // 
            this.ButtonPressIcon1.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon1.Image = global::Ultra_Small_Touch_SW_CT.Properties.Resources.Yubu1;
            this.ButtonPressIcon1.Location = new System.Drawing.Point(729, 0);
            this.ButtonPressIcon1.Name = "ButtonPressIcon1";
            this.ButtonPressIcon1.Size = new System.Drawing.Size(120, 40);
            this.ButtonPressIcon1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ButtonPressIcon1.TabIndex = 84;
            this.ButtonPressIcon1.TabStop = false;
            this.ButtonPressIcon1.Visible = false;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Silver;
            this.label8.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label8.Location = new System.Drawing.Point(10, 200);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(860, 1);
            this.label8.TabIndex = 300;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(137)))), ((int)(((byte)(140)))));
            this.label9.Location = new System.Drawing.Point(634, 106);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 12);
            this.label9.TabIndex = 201;
            this.label9.Text = "Device Type :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.Control;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(137)))), ((int)(((byte)(140)))));
            this.label10.Location = new System.Drawing.Point(634, 122);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 12);
            this.label10.TabIndex = 203;
            this.label10.Text = "Assign :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.Control;
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(137)))), ((int)(((byte)(140)))));
            this.label11.Location = new System.Drawing.Point(634, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(166, 12);
            this.label11.TabIndex = 200;
            this.label11.Text = "�ݒ���e";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(878, 221);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ButtonPressIcon1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbl_FW_Version);
            this.Controls.Add(this.DevicePb1);
            this.Controls.Add(this.StatusBox_lbl2);
            this.Controls.Add(this.StatusBox_lbl);
            this.Controls.Add(this.DeviceAssign_lbl1);
            this.Controls.Add(this.devicetype_lbl1);
            this.Controls.Add(this.Status_NC_pb);
            this.Controls.Add(this.Status_C_pb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(894, 538);
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "�����^USB�^�b�`�X�C�b�`, Configuration Tool ver ";
            ((System.ComponentModel.ISupportInitialize)(this.MouseMove_UD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_touch_sense)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Keyboard_pb)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DevicePb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Changevalue_btn;
        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.ToolTip ToggleLEDToolTip;
        private System.Windows.Forms.ToolTip PushbuttonStateTooltip;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ComboBox devicetype_combox;
        private System.Windows.Forms.ComboBox mousevalue_combx;
        private System.Windows.Forms.TextBox KeyboardValue_txtbx;
        private System.Windows.Forms.CheckBox Ctrl_cbox;
        private System.Windows.Forms.CheckBox Win_cbox;
        private System.Windows.Forms.CheckBox Shift_cbox;
        private System.Windows.Forms.CheckBox Alt_cbox;
        private System.Windows.Forms.NumericUpDown MouseMove_UD;
        private System.Windows.Forms.PictureBox ButtonPressIcon1;
        private System.Windows.Forms.PictureBox Status_C_pb;
        private System.Windows.Forms.PictureBox Status_NC_pb;
        private System.Windows.Forms.Label devicetype_lbl1;
        private System.Windows.Forms.Label DeviceAssign_lbl1;
        private System.Windows.Forms.PictureBox Arrow_Keyboard_pb;
        private System.Windows.Forms.Label StatusBox_lbl;
        private System.Windows.Forms.Label StatusBox_lbl2;
        private System.Windows.Forms.CheckBox Hold_CB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown num_touch_sense;
        private System.Windows.Forms.PictureBox DevicePb1;
        private System.Windows.Forms.ComboBox joyvalue_combox;
        private System.Windows.Forms.Label lbl_FW_Version;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label Speed_Mouse6_lbl;
        private System.Windows.Forms.Label Speed_Mouse5_lbl;
        private System.Windows.Forms.Label Key_assign_lbl;
        private System.Windows.Forms.Label Speed_Mouse4_lbl;
        private System.Windows.Forms.Button Reset_btn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}

